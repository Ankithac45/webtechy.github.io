import React from 'react';
import img1 from "./images/img1.jpg";
import img2 from "./images/img6.svg";

const App = () => {
    return ( < >
        <
        div className = "page" > < /div>   <
        h1 className = "Heading7" > Great Job!!You set a bar with this one < /h1> <
        h1 className = "Heading8" > You 'd make a Great</h1> <
        h1 className = "Heading9" > ANALYST < /h1> <
        img src = { img1 }
        alt = "Image can't be displayed"
        className = "imgr1" / >
        <
        img src = { img2 }
        alt = "Image can't be displayed"
        className = "imgr2" / >
        <
        />
    );
};

export default App;