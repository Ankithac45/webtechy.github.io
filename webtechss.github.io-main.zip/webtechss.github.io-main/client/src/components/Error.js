import React from 'react'

const Error = () => {
    return ( <
        >
        <
        h1 className = "errorpage" > 404 < /h1>  <
        h2 className = "errormsg" > We are sorry, page not found! < /h2> <
        />
    )
}

export default Error